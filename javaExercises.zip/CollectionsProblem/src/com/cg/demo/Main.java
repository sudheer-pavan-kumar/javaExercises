package com.cg.demo;

import java.util.List;

public class Main {

	public static void main(String[] args) {

		EmployeeService service = new EmployeeService();
		
		//call the functions
	}

}
