package com.cg.demos;

import java.util.List;

/*input
 ===== 
 String input1="raja/pavan/anju"
 char input2='/'
 
 output
 ====== 
 List<String> output1=["ajar","navap","ujna"];
*/

//split the string using the second input and form a list by
//reversing the each and every string

public class StringDemo3 {

	public List<String> getStrings(String input1, char input2){
		return null;
		
	}
	
	public static void main(String[] args) {

		String input1="raja/pavan/anju";
		char input2 = '/';

	}

}
